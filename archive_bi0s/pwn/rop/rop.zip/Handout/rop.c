#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
void initialize(){
	alarm(30);
	setvbuf(stdin,NULL,2,0);
	setvbuf(stdout,NULL,2,0);
}
int main(){
	initialize();
	char buf[10];
	puts("Try your best to end Thanos's rule forever !!!");
	puts("Give me something ..");
	gets(buf);
	return 0;
}
