#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void initialize(){
	alarm(30);
	setvbuf(stdin,NULL,2,0);
	setvbuf(stdout,NULL,2,0);
}
void check(int a){
	if(a){
		puts("I am strong enough.");
		puts("Thanks. You can take your flag");
		system("/bin/cat flag.txt");
		exit(0);
}
	else{
		puts("You failed to do the job");
		exit(0);
}
}
int main(){
	initialize();
	int a=0;
	char buf[20];
	puts("Hey buddy !");
	puts("Feed me something so that I can grow strong and defeat Thanos.");
	gets(buf);
	check(a);
	return 0;
}
